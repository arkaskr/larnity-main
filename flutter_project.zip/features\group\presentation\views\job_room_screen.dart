import 'package:flutter/material.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:hugeicons/styles/stroke_rounded.dart';
import 'package:larnity/src/core/constants/app_size.dart';
import 'package:larnity/src/core/constants/app_strings.dart';
import 'package:larnity/src/core/extensions/extensions.dart';
import 'package:larnity/src/core/theme/app_colors.dart';
import 'package:larnity/src/core/theme/theme.dart';
import 'package:larnity/src/core/ui/widgets/app_button.dart';
import 'package:larnity/src/features/group/presentation/widgets/add_job.dart';
import 'package:larnity/src/features/group/presentation/widgets/add_resource.dart';
import 'package:larnity/src/features/group/presentation/widgets/job_card.dart';
import 'package:larnity/src/features/group/presentation/widgets/resource_card.dart';
import 'package:larnity/src/features/group/presentation/widgets/settings/create_challenge.dart';

class JobRoomScreen extends StatelessWidget {
  const JobRoomScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: AppSizes.xs),
        child: SingleChildScrollView(
          child: Column(
            children: [
              AppSizes.xs.ph,
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        AppStrings.jobRoom,
                        style: AppTextStyles.headline2(color: AppColors.white),
                      ),

                      Text(
                        "0${AppStrings.jobsAvailable}",
                        style: AppTextStyles.overLine(),
                      ),
                    ],
                  ),

                  AppButton(
                    isExpanded: false,
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (context) => Dialog(
                          backgroundColor: AppColors.bgBlue,
                          child: AddJob(),
                        ),
                      );
                    },
                    prefix: HugeIcon(
                      icon: HugeIconsStrokeRounded.addCircle,
                      color: AppColors.black,
                    ),
                    label: AppStrings.postJob,
                    labelStyle: AppTextStyles.bodyText2(color: AppColors.black),
                    bgColor: AppColors.primaryOrange,
                    radius: AppSizes.xxxs,
                  ),
                ],
              ),
              AppSizes.xxxlg.ph,
              JobCard(),
            ],
          ),
        ),
      ),
    );
  }
}
